#!/usr/bin/ruby

# Course: CIS*3260: Software Design IV | A1: Ruby
# Name: Mitchell Van Braeckel
# Student Number: 1002297
# Email: mvanbrae@uoguelph.ca
# Due Date: September 27, 2021
# Professor: Mark Wineberg
# Language: Ruby

require "./Randomizer.rb"

# An "abstract class" used for polymorphism and to store common methods
# Note: All RandomizerContainer objects are created empty. Therefore they are just called with 'new' (e.g. `Cup.new`)
class RandomizerContainer
    # Default constructor for a RandomizerContainer object
    def initialize
        @randomizers = []
    end

    # Stores a randomizer in the container
    def store(r)
        raise ArgumentError, "Randomizer '#{r}' is invalid - must be a Randomizer instance." unless r.is_a?(Randomizer)
        @randomizers << r
    end

    # Get each randomizer in the given contained & store it in self (without emptying the container's randomizers)
    def copy_all(rc)
        raise ArgumentError, "RandomizerContainer '#{rc}' is invalid - must be a RandomizerContainer instance." unless rc.is_a?(RandomizerContainer)
        rc.randomizers.each do |r|
            @randomizers << r.clone
        end
    end

    # Get each randomizer in the given container & store it in self (removing it from the given container's randomizers)
    def move_all(rc)
        self.copy_all(rc)
        rc.empty
    end

    # Removes all members of the container
    def empty
        @randomizers = []
        nil
    end

    # Returns a copy of the randomizers in the container (so it isn't connected by reference, thus not breaking encapsulation)
    def randomizers
        @randomizers.clone
    end
end