# RubyRandomizerCoinDice_3260

Course: CIS*3260: Software Design IV | A1: Ruby
Name: Mitchell Van Braeckel
Student Number: 1002297
Email: mvanbrae@uoguelph.ca
Due Date: September 27, 2021
Professor: Mark Wineberg
Language: Ruby

## A Game of Coins and Dice feat. Bags, Cups, and Hands

Please note that where the A1 documentation and/or the posted Q&A was not sufficient, I took my own liberties. This being said, it's nothing too severe. For example, where applicable in an "abstract" class, a function is sometimes not implemented but is by its child(ren). In addition, in some places I opt to raise an error for invalid arguments to functions. Furthermore, some things (like those involving descriptions) will succeed silently even when bad info is passed in (i.e. it filters based on those bad keys and/or values and doesn't find any matches since none exist with those bad keys)
